# SAP Best Practices originals

This folder holds SAP's own published documents, unchanged, for the scope items in the reference process. They are not generated for the demo: download them from SAP and save them here.

## What to download

For each scope item: J45 Procurement of Direct Materials, BD9 Sell from Stock, J59 Accounts Receivable, J60 Accounts Payable, J58 Accounting and Financial Close.

1. The test script.
2. The process flow diagram.

Choose the release that matches the project: SAP S/4HANA 2025, country version US.

## Where to get them

1. Open SAP Signavio Process Navigator, through SAP for Me (Services & Support, ALM tab). An SAP account is needed.
2. Search for the solution process by its scope item ID, for example J45.
3. The process flow is shown on the process page. The test script is under Accelerators.
4. Save each file in this folder. Keep SAP's file names, or prefix them with the scope item ID.

## Who and when

- Published by: SAP.
- SAP Activate phase: available from Prepare, before any customer decision.
- Read by: the standard content reader (R1).

## Use

These are SAP documents. Keep them for internal project use and check SAP's terms before sharing them outside the organisation. The Northfield versions adapted from them are in 02-Explore/Customised-Test-Scripts.
