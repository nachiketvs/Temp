# Input-2 change log (29 October 2026)

Original files are kept in `.Input-2-original-backup` and `Input-2.zip`.

- 01 J45: standard script step 2 now uses SAP sample values (plant 1710), not customer keys; "Example company" row relabelled.
- 04 Process design: DD-SD-014 corrected to F2S-SD-014; open point OP-SD-07 changed from the freight tolerance (an accounts payable topic) to tax determination, which belongs to BD9.
- 08 CR-OTC-017: band now reads "above 1.00% and up to and including 1.50%", closing the gap between 1.00% and 1.01%.
- 03 Fit to standard: F2S-FI-008 now records that Finance must confirm an absolute cap (the source of open item OPEN-FI-001).
- 07 Requirements: added PTP-201, PTP-205 and OTC-405, which the fit-to-standard sheet referred to but the backlog did not contain.
- 09 Roles: added Terminal Operator, Revenue Accountant, Purchasing Manager and Accounts Payable Manager, which process steps used but had no test user. Shipping Specialist now covers the delivery only.
- Realize 03 Users: added TST_AP01 (was in the roles list but missing here) and the four new role users. TST_SHIP01 stays "Requested" on purpose: it is the readiness-check example.
- 11 L4 table: added step BD9-40A Review accounting document, which the process design and design pack used but the step table lacked.
- Realize 02 Fiori notes: role name "AP Accountant" written in full.
- Realize 04 Failure examples: FAIL-FI-01 evidence now points to F2S-FI-008, not to the BD9 process design.
- Design pack: coverage now lists acceptance criterion AC-OTC-401-03 (ticket reference) and every SD risk with an explicit status; E2E-O1 marked partly covered; tax assumption linked to OPEN-SD-001.
- Knowledge Pack: open items split into OPEN-SD-001 (tax) and OPEN-FI-001 (freight cap); roles, requirements and F2S-FI-008 updated to match the source files; BD9 standard entry now states plainly that it is a fallback from the SME step table.

The `.inspect.ndjson` files are inspection dumps from the original generation and describe the files before these corrections.
