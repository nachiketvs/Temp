#!/usr/bin/env python3
"""
Builds the EXPANDED guides in the Codex visual language.

Reuses the design system (map / notes / diagram / caption / scenario /
answer / lab / check) extracted from Day01-Selenium-Anatomy-Expanded.html,
and adds a question bank + rapid-fire drill mode on top of it.

Usage:  python3 build.py selenium.json
"""
import json, re, sys, os

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(HERE))
STYLE_SRC = os.path.join(ROOT, "Day01-Selenium-Anatomy-Expanded.html")

EXTRA_CSS = """
  /* ---- question bank, in the same visual language ---- */
  .qwrap{margin:22px 0}
  .qhead{display:flex;align-items:center;gap:12px;flex-wrap:wrap;margin:0 0 10px}
  .qhead h4{margin:0;font-size:15px}
  .qcount{font-size:12px;color:var(--muted)}
  .q{background:var(--paper);border:1px solid var(--line);border-radius:9px;margin:7px 0;overflow:hidden}
  .q>.qq{padding:11px 14px;cursor:pointer;display:flex;gap:11px;align-items:flex-start;font-weight:600;font-size:13.5px}
  .q>.qq:hover{background:#f4f8fd}
  .q .num{color:#9aa5b1;font-family:var(--mono,monospace);font-size:12px;flex:0 0 34px}
  .q .lvl{flex:0 0 auto;font-size:9.5px;padding:3px 8px;border-radius:10px;letter-spacing:.06em;
          text-transform:uppercase;font-weight:700;margin-left:auto}
  .lvl.core{background:#e3f5e9;color:#136b32}
  .lvl.deep{background:#f0e9fb;color:#5c3592}
  .lvl.mgr{background:#fff3d9;color:#8a5200}
  .q .qa{display:none;padding:11px 14px 13px 59px;color:#33404f;font-size:13px;
         border-top:1px solid var(--line);background:#fbfcfe}
  .q.open .qa{display:block}
  .q.open{border-color:#9fc0ea}
  .qbtn{background:var(--paper);border:1px solid var(--line);border-radius:6px;padding:6px 12px;
        font-size:12.5px;cursor:pointer;font-family:inherit;color:inherit}
  .qbtn:hover{border-color:#1769c2;color:#1769c2}
  .qbtn.primary{background:#1769c2;color:#fff;border-color:#1769c2;font-weight:700}
  #drill{position:fixed;inset:0;background:rgba(244,247,251,.97);display:none;z-index:60;
         padding:36px 18px;overflow-y:auto}
  #drill.on{display:block}
  .drillcard{max-width:760px;margin:34px auto;background:#fff;border:1px solid var(--line);
             border-radius:12px;padding:28px;box-shadow:0 6px 24px rgba(20,30,50,.12)}
  .drillcard .dq{font-size:18px;font-weight:700;line-height:1.5;margin:12px 0 18px}
  .drillcard .da{display:none;color:#33404f;font-size:14.5px;border-top:1px solid var(--line);padding-top:14px}
  .drillcard.rev .da{display:block}
  .drillmeta{font-size:11px;color:var(--muted);letter-spacing:.08em;text-transform:uppercase;font-weight:700}
  .dctl{display:flex;gap:9px;flex-wrap:wrap;margin-top:20px;align-items:center}
  @media print{nav,#drill,.qbtn{display:none}main{padding:0}}

  /* == layout: full-width diagrams, notes stacked underneath == */
  .map{display:block !important}
  .map > .diagram{margin:18px 0 0 !important}
  .map > .notes{margin:12px 0 20px !important}
  .diagram{overflow:visible !important}
  .diagram svg, .map svg, svg{min-width:0 !important; max-width:100% !important;
                              width:100% !important; height:auto !important; display:block}
  .notes dl{columns:2; column-gap:28px}
  .notes dl dt{break-after:avoid-column; -webkit-column-break-after:avoid}
  .notes dl dd{break-inside:avoid-column; -webkit-column-break-inside:avoid; margin-bottom:10px}
  .notes > p, .notes > .box{break-inside:avoid}
  @media(max-width:900px){
    .two,.three,.outcomes{grid-template-columns:1fr !important}
    .notes dl{columns:1}
  }
"""


def style():
    src = open(STYLE_SRC, encoding="utf-8").read()
    return re.search(r"<style>(.*?)</style>", src, re.S).group(1)


def esc(s):
    return s.replace("\\", "\\\\").replace('"', '\\"')


def render(d):
    css = style() + EXTRA_CSS + d.get("extracss", "")
    secs, qs = d["sections"], d["questions"]

    nav = "".join(
        '<a href="#%s">%s</a>' % (s["id"], s["nav"]) for s in secs
    )

    body = []
    for s in secs:
        body.append('<section id="%s">' % s["id"])
        body.append("<h3>%s</h3>" % s["title"])
        if s.get("lead"):
            body.append('<p class="lead">%s</p>' % s["lead"])
        h = s["html"]
        body.append("\n".join(h) if isinstance(h, list) else h)
        if s.get("qsec"):
            body.append(
                '<div class="qwrap"><div class="qhead"><h4>Practice questions</h4>'
                '<span class="qcount" data-count="%s"></span>'
                '<button class="qbtn" onclick="toggleAll(\'%s\')">Expand / collapse all</button>'
                '<button class="qbtn" onclick="startDrill(\'%s\')">Drill this section</button>'
                '</div><div class="qlist" data-sec="%s"></div></div>'
                % (s["qsec"], s["qsec"], s["qsec"], s["qsec"])
            )
        body.append("</section>")
    body = "\n".join(body)

    qjs = ",\n".join(
        '["%s","%s","%s","%s"]' % (q[0], q[1], esc(q[2]), esc(q[3])) for q in qs
    )
    names = {s["qsec"]: s["secname"] for s in secs if s.get("qsec")}
    pills = "".join(
        '<span class="pill%s">%s</span>' % (p[1], p[0].replace("{n}", str(len(qs))))
        for p in d["pills"]
    )
    refs = " · ".join(
        '<a href="%s" target="_blank" rel="noopener">%s</a>' % (u, t)
        for t, u in d.get("refs", [])
    )

    return """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>%(short)s | QE COE Skill Building</title>
<style>%(css)s</style>
</head>
<body>
<div class="layout">
<nav aria-label="Guide sections">
  <h1>QE COE Skill Building</h1><div class="title">%(label)s</div>
  %(nav)s
  <div class="nav-note">
    <b id="progressText">0 / 0 practice items</b>
    <div class="progress"><i id="progressBar"></i></div>
    <div style="margin-top:6px" id="qseen">0 / %(nq)d questions opened</div>
    <div style="margin-top:8px"><button class="qbtn primary" style="width:100%%" onclick="startDrill()">▶ Rapid-fire drill</button></div>
    <div style="margin-top:7px">Progress saves in this browser.</div>
  </div>
</nav>
<main>
<header>
  <h2>%(title)s</h2>
  %(intro)s
  <div style="margin-top:10px">%(pills)s</div>
</header>

%(body)s

<footer>
%(footer)s
<p class="source">%(source)s</p>
</footer>
</main></div>

<div id="drill"><div class="drillcard" id="dcard">
  <div class="drillmeta"><span id="dmeta"></span></div>
  <div class="dq" id="dq"></div>
  <div class="da" id="da"></div>
  <div class="dctl">
    <button class="qbtn primary" onclick="reveal()">Reveal (Space)</button>
    <button class="qbtn" onclick="nextDrill()">Next (→)</button>
    <button class="qbtn" onclick="endDrill()">Exit (Esc)</button>
    <span style="margin-left:auto;color:#5c6875;font-size:12.5px" id="dscore"></span>
  </div>
</div></div>

<script>
const SECNAMES = %(names)s;
const KEY = "%(key)s";
const Q = [
%(qjs)s
];

/* ---------- progress (checks + questions) ---------- */
let store={}; try{ store=JSON.parse(localStorage.getItem(KEY)||"{}"); }catch(e){ store={}; }
function save(){ try{ localStorage.setItem(KEY, JSON.stringify(store)); }catch(e){} }

/* ---------- question rendering ---------- */
document.querySelectorAll(".qlist").forEach(list=>{
  const sec=list.dataset.sec; let n=0;
  Q.forEach((q,i)=>{
    if(q[0]!==sec) return; n++;
    const idx=i+1;
    const d=document.createElement("div");
    d.className="q"+(store["q"+idx]?" seen":"");
    d.innerHTML='<div class="qq"><span class="num">'+idx+'</span><span>'+q[2]+
                '</span><span class="lvl '+q[1]+'">'+q[1]+'</span></div>'+
                '<div class="qa">'+q[3]+'</div>';
    d.querySelector(".qq").addEventListener("click",()=>{
      d.classList.toggle("open");
      if(d.classList.contains("open")){ store["q"+idx]=1; save(); updateProg(); }
    });
    list.appendChild(d);
  });
  const c=document.querySelector('.qcount[data-count="'+sec+'"]');
  if(c) c.textContent=n+" questions";
});
function toggleAll(sec){
  const list=document.querySelector('.qlist[data-sec="'+sec+'"]');
  const any=[...list.children].some(q=>q.classList.contains("open"));
  [...list.children].forEach(q=>{ q.classList.toggle("open",!any); });
  if(!any){ [...list.children].forEach(q=>{ store["q"+q.querySelector(".num").textContent]=1; }); save(); updateProg(); }
}

/* ---------- checkbox practice items ---------- */
const checks=[...document.querySelectorAll(".check input")];
checks.forEach((c,i)=>{
  c.checked=!!store["c"+i];
  c.closest(".check").classList.toggle("done",c.checked);
  c.addEventListener("change",()=>{
    store["c"+i]=c.checked?1:0; save();
    c.closest(".check").classList.toggle("done",c.checked); updateProg();
  });
});
function updateProg(){
  const done=checks.filter(c=>c.checked).length;
  const pt=document.getElementById("progressText");
  if(pt){ pt.textContent=done+" / "+checks.length+" practice items";
          document.getElementById("progressBar").style.width=
            (checks.length?Math.round(done/checks.length*100):0)+"%%"; }
  const seen=Q.filter((q,i)=>store["q"+(i+1)]).length;
  const qs=document.getElementById("qseen");
  if(qs) qs.textContent=seen+" / "+Q.length+" questions opened";
}
updateProg();

/* ---------- drill mode ---------- */
let deck=[],dpos=0;
function startDrill(sec){
  deck=Q.map((q,i)=>[q,i+1]).filter(x=>!sec||x[0][0]===sec);
  for(let i=deck.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[deck[i],deck[j]]=[deck[j],deck[i]];}
  dpos=0; document.getElementById("drill").classList.add("on"); showDrill();
}
function showDrill(){
  if(dpos>=deck.length){ endDrill(); return; }
  const [q,n]=deck[dpos];
  document.getElementById("dmeta").textContent=(SECNAMES[q[0]]||q[0])+" · "+q[1]+" · Q"+n;
  document.getElementById("dq").textContent=q[2];
  document.getElementById("da").innerHTML=q[3];
  document.getElementById("dcard").classList.remove("rev");
  document.getElementById("dscore").textContent=(dpos+1)+" / "+deck.length;
  store["q"+n]=1; save(); updateProg();
  window.scrollTo(0,0);
}
function reveal(){ document.getElementById("dcard").classList.add("rev"); }
function nextDrill(){ dpos++; showDrill(); }
function endDrill(){ document.getElementById("drill").classList.remove("on"); }
document.addEventListener("keydown",e=>{
  const on=document.getElementById("drill").classList.contains("on");
  if(!on){ if(e.key==="d"||e.key==="D"){ if(!/input|textarea/i.test(e.target.tagName)) startDrill(); } return; }
  if(e.key===" "){ e.preventDefault(); reveal(); }
  if(e.key==="ArrowRight"||e.key==="Enter"){ e.preventDefault(); nextDrill(); }
  if(e.key==="Escape"){ endDrill(); }
});

/* ---------- nav highlight ---------- */
const links=[...document.querySelectorAll("nav a")];
const io=new IntersectionObserver(es=>es.forEach(e=>{
  if(e.isIntersecting) links.forEach(a=>a.classList.toggle("active",a.getAttribute("href")==="#"+e.target.id));
}),{rootMargin:"-10%% 0px -78%% 0px"});
document.querySelectorAll("section").forEach(s=>io.observe(s));
</script>
</body>
</html>
""" % dict(
        short=d["short"], css=css, label=d["label"], nav=nav, title=d["title"],
        intro=d["intro"], pills=pills, body=body, nq=len(qs),
        names=json.dumps(names), key=d["key"], qjs=qjs,
        footer=("<p><b>Primary references:</b> %s</p>" % refs) if refs else "",
        source=d.get("source", ""),
    )


sys.path.insert(0, os.path.join(os.path.dirname(HERE)))
from darken_text import fix_svg_text, fix_css_color   # noqa: E402


def main():
    for path in sys.argv[1:]:
        d = json.load(open(os.path.join(HERE, path), encoding="utf-8"))
        out = os.path.join(ROOT, d["filename"])
        html = render(d)
        html, _ = fix_svg_text(html)      # no light text, ever
        html, _ = fix_css_color(html)
        open(out, "w", encoding="utf-8").write(html)
        print("built %s  (%d sections, %d questions)"
              % (d["filename"], len(d["sections"]), len(d["questions"])))


if __name__ == "__main__":
    main()
