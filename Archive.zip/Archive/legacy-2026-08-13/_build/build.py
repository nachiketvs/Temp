#!/usr/bin/env python3
"""
Builds the daily skill-building HTML files.

Reuses the CSS + drill engine from Day01 so every day looks and behaves identically
and content is the only thing authored per day.

Usage:  python3 build.py day02.json [day03.json ...]
"""
import json, re, sys, os

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
DAY1 = os.path.join(ROOT, "Day01-Selenium-Anatomy.html")


def shell():
    """Extract the <style> block and the render/drill JS from Day 1."""
    src = open(DAY1, encoding="utf-8").read()
    css = re.search(r"<style>(.*?)</style>", src, re.S).group(1)
    js = src.split("/* ================= RENDER ================= */", 1)[1]
    js = js.split("</script>", 1)[0]
    # make the drill-mode section names data-driven instead of hard-coded
    js = re.sub(r"const names = \{.*?\};", "const names = SECNAMES;", js, flags=re.S)
    return css, js


def esc(s):
    return s.replace("\\", "\\\\").replace('"', '\\"')


def render(d, css, js):
    secs = d["sections"]
    qs = d["questions"]
    label = d.get("label", "Day %s" % d["day"])
    key = d.get("key", "d%sprep" % d["day"])

    nav = []
    cur = None
    for s in secs:
        if s.get("group") and s["group"] != cur:
            cur = s["group"]
            nav.append(f'  <div class="grp">{cur}</div>')
        nav.append(f'  <a href="#{s["id"]}">{s["nav"]}</a>')
    nav = "\n".join(nav)

    body = []
    for s in secs:
        body.append(f'<section id="{s["id"]}">')
        h = s["html"]
        body.append("\n".join(h) if isinstance(h, list) else h)
        if s.get("qsec"):
            body.append(
                f'  <div class="qhead"><h4>Practice questions</h4>'
                f'<span class="qcount" data-count="{s["qsec"]}"></span>'
                f'<button onclick="toggleAll(\'{s["qsec"]}\')">Expand / collapse all</button></div>\n'
                f'  <div class="qlist" data-sec="{s["qsec"]}"></div>'
            )
        body.append("</section>\n")
    body = "\n".join(body)

    qjs = ",\n".join(
        '["%s","%s","%s","%s"]' % (q[0], q[1], esc(q[2]), esc(q[3])) for q in qs
    )
    wbjs = ",\n ".join('"%s"' % esc(w) for w in d["drills"])
    exjs = ",\n ".join('"%s"' % esc(e) for e in d["exit"])
    names = {s["qsec"]: s["secname"] for s in secs if s.get("qsec")}
    pills = "\n    ".join(
        f'<span class="pill{p[1]}">{p[0].replace("{n}", str(len(qs)))}</span>' for p in d["pills"]
    )

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{label} — {d['short']} | QE COE Skill Building</title>
<style>{css}
{d.get("extracss", "")}</style>
</head>
<body>
<div class="wrap">

<nav>
  <h1>QE COE Prep</h1>
  <div class="day">{label}</div>
  <div style="margin:-8px 18px 12px;font-size:11.5px;color:#8b97a4;letter-spacing:.04em">
    {d['stack']}</div>
  <div class="prog">
    <div><b id="pctTxt">0%</b> complete</div>
    <div class="bar"><i id="pctBar"></i></div>
    <div style="margin-top:8px;font-size:12px;color:var(--dim)" id="qseen">0 / {len(qs)} questions opened</div>
  </div>
{nav}
  <div style="padding:16px 18px">
    <button class="primary" onclick="startDrill()" style="width:100%">▶ Rapid-fire drill</button>
  </div>
</nav>

<main>

<header class="top">
  <h2>{label} — {d['title']}</h2>
  {d['intro']}
  <div style="margin-top:12px">
    {pills}
  </div>
</header>

{body}

<footer>
  <p><b>{label} exit criteria</b> — tick these honestly before you close the laptop:</p>
  <div id="exit"></div>
  {d['next']}
  <p style="color:#7a8593">Shortcuts: <span class="kbd">D</span> drill mode · <span class="kbd">Space</span> reveal answer · <span class="kbd">→</span> next · <span class="kbd">Esc</span> exit</p>
</footer>

</main>
</div>

<div id="drill">
  <div class="drillcard" id="dcard">
    <div class="drillmeta"><span id="dmeta"></span></div>
    <div class="dq" id="dq"></div>
    <div class="da" id="da"></div>
    <div class="controls" style="margin-top:22px">
      <button class="primary" onclick="reveal()">Reveal (Space)</button>
      <button onclick="nextDrill()">Next (→)</button>
      <button onclick="endDrill()">Exit (Esc)</button>
      <span style="margin-left:auto;color:#5c6875;font-size:13px" id="dscore"></span>
    </div>
  </div>
</div>

<script>
const SECNAMES = {json.dumps(names)};
const STOREKEY = "{key}";
const Q = [
{qjs}
];
const WB = [
 {wbjs}
];
const EXIT = [
 {exjs}
];
/* ================= RENDER ================= */{js}</script>
</body>
</html>
"""


def main():
    css, js = shell()
    # the extracted JS hard-codes Day 1's localStorage key; make it per-day
    js = js.replace('"d1prep"', "STOREKEY")
    for path in sys.argv[1:]:
        d = json.load(open(os.path.join(HERE, path), encoding="utf-8"))
        out = os.path.join(ROOT, d["filename"])
        open(out, "w", encoding="utf-8").write(render(d, css, js))
        print(f"built {d['filename']}  ({len(d['questions'])} questions)")


if __name__ == "__main__":
    main()
