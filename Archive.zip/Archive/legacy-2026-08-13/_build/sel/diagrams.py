#!/usr/bin/env python3
"""Inserts concept diagrams into Day01. Idempotent: refuses to run twice."""
import re, sys, os

P = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..",
                 "Day01-Selenium-Anatomy.html")
F = 'font-family="Verdana, Geneva, sans-serif"'

DOM = '''<div class="diag">
    <svg viewBox="0 0 940 300" xmlns="http://www.w3.org/2000/svg" ''' + F + '''>
      <defs><marker id="d1" markerWidth="10" markerHeight="10" refX="9" refY="5" orient="auto">
        <path d="M0,0 L10,5 L0,10 z" fill="#a06000"/></marker></defs>
      <text x="14" y="18" font-size="11" font-weight="bold" fill="#5c6875">HTML IS THE RECIPE. THE DOM IS THE MEAL ON THE TABLE.</text>
      <rect x="20" y="32" width="230" height="150" rx="8" fill="#f9fafc" stroke="#d9e0e9"/>
      <text x="135" y="54" font-size="12" font-weight="bold" text-anchor="middle" fill="#243447">HTML — text the server sent</text>
      <text x="34" y="80" font-size="10.5" fill="#25303d" font-family="monospace">&lt;form id="login-form"&gt;</text>
      <text x="46" y="98" font-size="10.5" fill="#25303d" font-family="monospace">&lt;label&gt;Email&lt;/label&gt;</text>
      <text x="46" y="116" font-size="10.5" fill="#25303d" font-family="monospace">&lt;input id="email"&gt;</text>
      <text x="46" y="134" font-size="10.5" fill="#25303d" font-family="monospace">&lt;button id="submit"&gt;</text>
      <text x="34" y="152" font-size="10.5" fill="#25303d" font-family="monospace">&lt;/form&gt;</text>
      <text x="135" y="173" font-size="10" text-anchor="middle" fill="#8f2419">static. never changes after it arrives</text>
      <line x1="252" y1="105" x2="292" y2="105" stroke="#a06000" stroke-width="2.5" marker-end="url(#d1)"/>
      <text x="272" y="96" font-size="9.5" text-anchor="middle" fill="#7a4a00">browser</text>
      <text x="272" y="126" font-size="9.5" text-anchor="middle" fill="#7a4a00">reads it</text>
      <rect x="300" y="32" width="360" height="150" rx="8" fill="#f4faf6" stroke="#177a3c" stroke-width="2"/>
      <text x="480" y="54" font-size="12" font-weight="bold" text-anchor="middle" fill="#0f5528">THE DOM — the live page, right now</text>
      <rect x="420" y="66" width="120" height="26" rx="4" fill="#e8f3ea" stroke="#177a3c"/>
      <text x="480" y="83" font-size="10.5" text-anchor="middle" fill="#0f5528">form</text>
      <line x1="480" y1="92" x2="480" y2="102" stroke="#8b97a4" stroke-width="1.5"/>
      <line x1="360" y1="102" x2="600" y2="102" stroke="#8b97a4" stroke-width="1.5"/>
      <line x1="360" y1="102" x2="360" y2="112" stroke="#8b97a4" stroke-width="1.5"/>
      <line x1="480" y1="102" x2="480" y2="112" stroke="#8b97a4" stroke-width="1.5"/>
      <line x1="600" y1="102" x2="600" y2="112" stroke="#8b97a4" stroke-width="1.5"/>
      <rect x="316" y="112" width="88" height="26" rx="4" fill="#e8f3ea" stroke="#177a3c"/>
      <text x="360" y="129" font-size="10.5" text-anchor="middle" fill="#0f5528">label</text>
      <rect x="436" y="112" width="88" height="26" rx="4" fill="#e8f3ea" stroke="#177a3c"/>
      <text x="480" y="129" font-size="10.5" text-anchor="middle" fill="#0f5528">input</text>
      <rect x="556" y="112" width="88" height="26" rx="4" fill="#e8f3ea" stroke="#177a3c"/>
      <text x="600" y="129" font-size="10.5" text-anchor="middle" fill="#0f5528">button</text>
      <rect x="316" y="146" width="328" height="28" rx="4" fill="#fdf3dd" stroke="#a06000" stroke-dasharray="4 3"/>
      <text x="480" y="164" font-size="10" text-anchor="middle" fill="#7a4a00">code running in the browser adds, removes and redraws these constantly</text>
      <rect x="676" y="32" width="248" height="150" rx="8" fill="#fffafa" stroke="#c0392b" stroke-width="2"/>
      <text x="800" y="54" font-size="12" font-weight="bold" text-anchor="middle" fill="#8f2419">YOUR TEST WORKS HERE</text>
      <text x="692" y="78" font-size="10.5" fill="#33404f">View page source → you see HTML</text>
      <text x="692" y="97" font-size="10.5" fill="#33404f">Inspect element → you see the DOM</text>
      <text x="692" y="123" font-size="10.5" font-weight="bold" fill="#8f2419">In a modern app these are</text>
      <text x="692" y="140" font-size="10.5" font-weight="bold" fill="#8f2419">wildly different. The source</text>
      <text x="692" y="157" font-size="10.5" font-weight="bold" fill="#8f2419">may be almost empty.</text>
      <rect x="20" y="200" width="904" height="86" rx="8" fill="#fffdf7" stroke="#d99500"/>
      <text x="38" y="222" font-size="11.5" font-weight="bold" fill="#7a4a00">THE CONSEQUENCE — this one idea explains most of Block 3</text>
      <text x="38" y="244" font-size="10.5" fill="#33404f">"The element isn't there" almost never means the element is missing. It means IT ISN'T THERE YET — you looked before the</text>
      <text x="38" y="262" font-size="10.5" fill="#33404f">browser finished putting it there. The HTML arrived in one go; the DOM is still being assembled.</text>
      <text x="38" y="280" font-size="10.5" font-weight="bold" fill="#8f2419">Selenium sits outside the browser and cannot see when that assembly finishes. That is why waits exist.</text>
    </svg>
  </div>
  '''

CAST = '''<div class="diag">
    <svg viewBox="0 0 940 250" xmlns="http://www.w3.org/2000/svg" ''' + F + '''>
      <defs><marker id="c1" markerWidth="9" markerHeight="9" refX="8" refY="4.5" orient="auto">
        <path d="M0,0 L9,4.5 L0,9 z" fill="#5c6875"/></marker></defs>
      <rect x="12" y="46" width="140" height="62" rx="7" fill="#e4edfa" stroke="#1a6bd4"/>
      <text x="82" y="68" font-size="11" font-weight="bold" text-anchor="middle" fill="#134b96">1. Test code</text>
      <text x="82" y="85" font-size="9.5" text-anchor="middle" fill="#5c6875">the instructions</text>
      <text x="82" y="99" font-size="9.5" font-weight="bold" text-anchor="middle" fill="#8f2419">C#</text>
      <rect x="166" y="46" width="140" height="62" rx="7" fill="#f2f0f8" stroke="#6a3fa0"/>
      <text x="236" y="68" font-size="11" font-weight="bold" text-anchor="middle" fill="#3d2464">2. Test runner</text>
      <text x="236" y="85" font-size="9.5" text-anchor="middle" fill="#5c6875">what runs, in what order</text>
      <text x="236" y="99" font-size="9.5" font-weight="bold" text-anchor="middle" fill="#8f2419">NUnit</text>
      <rect x="320" y="46" width="150" height="62" rx="7" fill="#fdf3dd" stroke="#a06000" stroke-width="2"/>
      <text x="395" y="68" font-size="11" font-weight="bold" text-anchor="middle" fill="#7a4a00">3. Automation library</text>
      <text x="395" y="85" font-size="9.5" text-anchor="middle" fill="#5c6875">"click that button"</text>
      <text x="395" y="99" font-size="9.5" font-weight="bold" text-anchor="middle" fill="#8f2419">SELENIUM — only this</text>
      <rect x="484" y="46" width="140" height="62" rx="7" fill="#fdf3dd" stroke="#a06000"/>
      <text x="554" y="68" font-size="11" font-weight="bold" text-anchor="middle" fill="#7a4a00">4. Browser driver</text>
      <text x="554" y="85" font-size="9.5" text-anchor="middle" fill="#5c6875">a SEPARATE program</text>
      <text x="554" y="99" font-size="9.5" font-weight="bold" text-anchor="middle" fill="#8f2419">chromedriver</text>
      <rect x="638" y="46" width="140" height="62" rx="7" fill="#e8f3ea" stroke="#177a3c"/>
      <text x="708" y="68" font-size="11" font-weight="bold" text-anchor="middle" fill="#0f5528">5. The browser</text>
      <text x="708" y="85" font-size="9.5" text-anchor="middle" fill="#5c6875">does the clicking</text>
      <text x="708" y="99" font-size="9.5" font-weight="bold" text-anchor="middle" fill="#8f2419">Chrome</text>
      <rect x="792" y="46" width="136" height="62" rx="7" fill="#fbe9e6" stroke="#c0392b"/>
      <text x="860" y="68" font-size="11" font-weight="bold" text-anchor="middle" fill="#8f2419">6. The application</text>
      <text x="860" y="85" font-size="9.5" text-anchor="middle" fill="#5c6875">what you are testing</text>
      <line x1="152" y1="77" x2="163" y2="77" stroke="#5c6875" stroke-width="2" marker-end="url(#c1)"/>
      <line x1="306" y1="77" x2="317" y2="77" stroke="#5c6875" stroke-width="2" marker-end="url(#c1)"/>
      <line x1="470" y1="77" x2="481" y2="77" stroke="#5c6875" stroke-width="2" marker-end="url(#c1)"/>
      <line x1="624" y1="77" x2="635" y2="77" stroke="#5c6875" stroke-width="2" marker-end="url(#c1)"/>
      <line x1="778" y1="77" x2="789" y2="77" stroke="#5c6875" stroke-width="2" marker-end="url(#c1)"/>
      <text x="14" y="30" font-size="11" font-weight="bold" fill="#5c6875">SIX PIECES, SIX SEPARATE JOBS — blurring any two is where confusion starts</text>
      <text x="82" y="132" font-size="9.5" text-anchor="middle" fill="#8b97a4">the script</text>
      <text x="236" y="132" font-size="9.5" text-anchor="middle" fill="#8b97a4">stage manager</text>
      <text x="395" y="132" font-size="9.5" text-anchor="middle" fill="#8b97a4">the director</text>
      <text x="554" y="132" font-size="9.5" text-anchor="middle" fill="#8b97a4">the interpreter</text>
      <text x="708" y="132" font-size="9.5" text-anchor="middle" fill="#8b97a4">the actor</text>
      <text x="860" y="132" font-size="9.5" text-anchor="middle" fill="#8b97a4">the play</text>
      <rect x="12" y="152" width="916" height="86" rx="8" fill="#fffdf7" stroke="#d99500"/>
      <text x="30" y="174" font-size="11.5" font-weight="bold" fill="#7a4a00">THE TWO SEPARATIONS TO BE PEDANTIC ABOUT</text>
      <text x="30" y="196" font-size="10.5" fill="#33404f">1. SELENIUM IS NOT A TESTING TOOL. It drives browsers. No concept of a test, no pass or fail, no reporting. Everything that</text>
      <text x="46" y="213" font-size="10.5" fill="#33404f">makes it feel like a testing tool comes from box 2 and from the framework you wrapped around it.</text>
      <text x="30" y="233" font-size="10.5" fill="#33404f">2. THE DRIVER IS A THIRD PROGRAM, not part of Selenium and not part of the browser — which is why versions used to mismatch.</text>
    </svg>
  </div>
  '''

STALE = '''<div class="diag">
    <svg viewBox="0 0 940 330" xmlns="http://www.w3.org/2000/svg" ''' + F + '''>
      <defs><marker id="s1" markerWidth="9" markerHeight="9" refX="8" refY="4.5" orient="auto">
        <path d="M0,0 L9,4.5 L0,9 z" fill="#1a6bd4"/></marker>
        <marker id="s2" markerWidth="9" markerHeight="9" refX="8" refY="4.5" orient="auto">
        <path d="M0,0 L9,4.5 L0,9 z" fill="#177a3c"/></marker>
        <marker id="s3" markerWidth="9" markerHeight="9" refX="8" refY="4.5" orient="auto">
        <path d="M0,0 L9,4.5 L0,9 z" fill="#c0392b"/></marker></defs>
      <text x="14" y="18" font-size="11" font-weight="bold" fill="#5c6875">THE CLOAKROOM TICKET — why StaleElementReferenceException happens</text>
      <rect x="60" y="32" width="150" height="34" rx="6" fill="#e4edfa" stroke="#1a6bd4"/>
      <text x="135" y="54" font-size="11" font-weight="bold" text-anchor="middle" fill="#134b96">YOUR TEST</text>
      <rect x="700" y="32" width="150" height="34" rx="6" fill="#e8f3ea" stroke="#177a3c"/>
      <text x="775" y="54" font-size="11" font-weight="bold" text-anchor="middle" fill="#0f5528">THE BROWSER</text>
      <line x1="135" y1="66" x2="135" y2="300" stroke="#c9d4e2" stroke-width="2"/>
      <line x1="775" y1="66" x2="775" y2="300" stroke="#c9d4e2" stroke-width="2"/>
      <line x1="140" y1="92" x2="770" y2="92" stroke="#1a6bd4" stroke-width="2" marker-end="url(#s1)"/>
      <text x="455" y="86" font-size="10.5" text-anchor="middle" fill="#134b96">FindElement(By.Id("submit"))  —  "find me the thing with id submit"</text>
      <line x1="770" y1="124" x2="140" y2="124" stroke="#177a3c" stroke-width="2" marker-end="url(#s2)"/>
      <text x="455" y="118" font-size="10.5" text-anchor="middle" fill="#0f5528">reply: reference "element-7f3a"  —  A TICKET, NOT THE ELEMENT</text>
      <rect x="300" y="140" width="310" height="44" rx="6" fill="#fdf3dd" stroke="#a06000" stroke-width="2"/>
      <text x="455" y="158" font-size="10.5" font-weight="bold" text-anchor="middle" fill="#7a4a00">MEANWHILE — the page redraws itself</text>
      <text x="455" y="175" font-size="9.5" text-anchor="middle" fill="#5c6875">a validation message appears, a table refreshes, a component re-renders</text>
      <line x1="775" y1="184" x2="775" y2="196" stroke="#a06000" stroke-width="2"/>
      <rect x="690" y="196" width="170" height="30" rx="5" fill="#fffafa" stroke="#c0392b" stroke-dasharray="4 3"/>
      <text x="775" y="215" font-size="9.5" text-anchor="middle" fill="#8f2419">"element-7f3a" now means nothing</text>
      <line x1="140" y1="252" x2="770" y2="252" stroke="#1a6bd4" stroke-width="2" marker-end="url(#s1)"/>
      <text x="455" y="246" font-size="10.5" text-anchor="middle" fill="#134b96">.Click()  —  "click the thing with ticket element-7f3a"</text>
      <line x1="770" y1="284" x2="140" y2="284" stroke="#c0392b" stroke-width="2.5" marker-end="url(#s3)"/>
      <text x="455" y="278" font-size="11" font-weight="bold" text-anchor="middle" fill="#8f2419">StaleElementReferenceException</text>
      <text x="14" y="318" font-size="10.5" fill="#33404f"><tspan font-weight="bold" fill="#8f2419">READ IT AS:</tspan> "the page changed under you" — NOT "the element is gone". The element is usually right there on screen.</text>
    </svg>
  </div>
  '''

LOCATORS = '''<div class="diag">
    <svg viewBox="0 0 940 340" xmlns="http://www.w3.org/2000/svg" ''' + F + '''>
      <text x="14" y="18" font-size="11" font-weight="bold" fill="#5c6875">THE STABILITY LADDER — pick the highest rung the application actually offers</text>
      <rect x="14" y="30" width="46" height="286" rx="6" fill="#f9fafc" stroke="#d9e0e9"/>
      <text x="37" y="60" font-size="10" font-weight="bold" text-anchor="middle" fill="#0f5528">S</text>
      <text x="37" y="74" font-size="10" font-weight="bold" text-anchor="middle" fill="#0f5528">T</text>
      <text x="37" y="88" font-size="10" font-weight="bold" text-anchor="middle" fill="#0f5528">A</text>
      <text x="37" y="102" font-size="10" font-weight="bold" text-anchor="middle" fill="#0f5528">B</text>
      <text x="37" y="116" font-size="10" font-weight="bold" text-anchor="middle" fill="#0f5528">L</text>
      <text x="37" y="130" font-size="10" font-weight="bold" text-anchor="middle" fill="#0f5528">E</text>
      <text x="37" y="230" font-size="10" font-weight="bold" text-anchor="middle" fill="#8f2419">B</text>
      <text x="37" y="244" font-size="10" font-weight="bold" text-anchor="middle" fill="#8f2419">R</text>
      <text x="37" y="258" font-size="10" font-weight="bold" text-anchor="middle" fill="#8f2419">I</text>
      <text x="37" y="272" font-size="10" font-weight="bold" text-anchor="middle" fill="#8f2419">T</text>
      <text x="37" y="286" font-size="10" font-weight="bold" text-anchor="middle" fill="#8f2419">T</text>
      <text x="37" y="300" font-size="10" font-weight="bold" text-anchor="middle" fill="#8f2419">L</text>
      <text x="37" y="314" font-size="10" font-weight="bold" text-anchor="middle" fill="#8f2419">E</text>
      <rect x="70" y="30" width="330" height="40" rx="6" fill="#e8f3ea" stroke="#177a3c" stroke-width="2"/>
      <text x="86" y="47" font-size="11" font-weight="bold" fill="#0f5528">Purpose-built test attribute</text>
      <text x="86" y="63" font-size="10" fill="#5c6875" font-family="monospace">[data-testid='checkout-submit']</text>
      <text x="418" y="47" font-size="10" fill="#33404f">Exists ONLY for testing, so nothing else has a reason to change it.</text>
      <text x="418" y="63" font-size="10" font-weight="bold" fill="#0f5528">The best answer — and it needs developer agreement, not a tool.</text>
      <rect x="70" y="80" width="330" height="40" rx="6" fill="#e8f3ea" stroke="#177a3c"/>
      <text x="86" y="97" font-size="11" font-weight="bold" fill="#0f5528">A meaningful id</text>
      <text x="86" y="113" font-size="10" fill="#5c6875" font-family="monospace">#email  ·  #login-form</text>
      <text x="418" y="97" font-size="10" fill="#33404f">Unique by design and fastest to resolve.</text>
      <text x="418" y="113" font-size="10" fill="#8f2419">Check it is not machine-generated — #ctl00_x2 is not an id, it is noise.</text>
      <rect x="70" y="130" width="330" height="40" rx="6" fill="#fdf3dd" stroke="#a06000"/>
      <text x="86" y="147" font-size="11" font-weight="bold" fill="#7a4a00">Accessible name / label / role</text>
      <text x="86" y="163" font-size="10" fill="#5c6875" font-family="monospace">the field labelled "Email"</text>
      <text x="418" y="147" font-size="10" fill="#33404f">Tied to what the user sees, so it survives restyling.</text>
      <text x="418" y="163" font-size="10" fill="#8f2419">Breaks on wording changes and on translation.</text>
      <rect x="70" y="180" width="330" height="40" rx="6" fill="#fdf3dd" stroke="#a06000"/>
      <text x="86" y="197" font-size="11" font-weight="bold" fill="#7a4a00">A stable, meaningful class</text>
      <text x="86" y="213" font-size="10" fill="#5c6875" font-family="monospace">.order-summary .total</text>
      <text x="418" y="197" font-size="10" fill="#33404f">Acceptable when the class describes MEANING.</text>
      <text x="418" y="213" font-size="10" fill="#8f2419">Classes describe appearance, and appearance is what designers change.</text>
      <rect x="70" y="230" width="330" height="40" rx="6" fill="#fffafa" stroke="#c0392b"/>
      <text x="86" y="247" font-size="11" font-weight="bold" fill="#8f2419">Text content</text>
      <text x="86" y="263" font-size="10" fill="#5c6875" font-family="monospace">//button[text()='Sign in']</text>
      <text x="418" y="247" font-size="10" fill="#33404f">Fine for a one-off. Not for a suite.</text>
      <text x="418" y="263" font-size="10" fill="#8f2419">Copy changes weekly. Dies instantly on a second language.</text>
      <rect x="70" y="280" width="330" height="40" rx="6" fill="#fbe9e6" stroke="#c0392b" stroke-width="2"/>
      <text x="86" y="297" font-size="11" font-weight="bold" fill="#8f2419">Position in the page structure</text>
      <text x="86" y="313" font-size="10" fill="#5c6875" font-family="monospace">/html/body/div[3]/div/form/div[2]/input</text>
      <text x="418" y="297" font-size="10" font-weight="bold" fill="#8f2419">NEVER. One extra wrapper div and every one of these breaks.</text>
      <text x="418" y="313" font-size="10" fill="#33404f">Finding these in a suite is the fastest way to size its maintenance cost.</text>
    </svg>
  </div>
  '''

WAITS = '''<div class="diag">
    <svg viewBox="0 0 940 380" xmlns="http://www.w3.org/2000/svg" ''' + F + '''>
      <defs><marker id="w1" markerWidth="9" markerHeight="9" refX="8" refY="4.5" orient="auto">
        <path d="M0,0 L9,4.5 L0,9 z" fill="#5c6875"/></marker></defs>
      <text x="14" y="18" font-size="11" font-weight="bold" fill="#5c6875">ONE TIMELINE, THREE STRATEGIES — the app takes 1.4s to show the button</text>
      <line x1="150" y1="42" x2="900" y2="42" stroke="#8b97a4" stroke-width="1.5" marker-end="url(#w1)"/>
      <text x="905" y="46" font-size="10" fill="#5c6875">time</text>
      <line x1="150" y1="36" x2="150" y2="48" stroke="#8b97a4" stroke-width="1.5"/>
      <text x="150" y="32" font-size="9.5" text-anchor="middle" fill="#5c6875">0.0s</text>
      <line x1="430" y1="36" x2="430" y2="48" stroke="#8b97a4" stroke-width="1.5"/>
      <text x="430" y="32" font-size="9.5" text-anchor="middle" fill="#5c6875">0.7s</text>
      <line x1="710" y1="36" x2="710" y2="330" stroke="#177a3c" stroke-width="2" stroke-dasharray="5 3"/>
      <text x="710" y="32" font-size="10" font-weight="bold" text-anchor="middle" fill="#0f5528">1.4s — button appears</text>
      <rect x="14" y="62" width="130" height="52" rx="6" fill="#fbe9e6" stroke="#c0392b"/>
      <text x="79" y="82" font-size="10.5" font-weight="bold" text-anchor="middle" fill="#8f2419">NO WAIT</text>
      <text x="79" y="99" font-size="9.5" text-anchor="middle" fill="#5c6875">look once</text>
      <rect x="150" y="72" width="16" height="32" rx="3" fill="#c0392b"/>
      <text x="200" y="93" font-size="10.5" fill="#8f2419">looks at 0.0s, nothing there, FAILS immediately</text>
      <text x="620" y="93" font-size="10" font-weight="bold" fill="#8f2419">← element arrives 1.4s too late</text>
      <rect x="14" y="126" width="130" height="72" rx="6" fill="#fdf3dd" stroke="#a06000"/>
      <text x="79" y="146" font-size="10.5" font-weight="bold" text-anchor="middle" fill="#7a4a00">FIXED SLEEP</text>
      <text x="79" y="163" font-size="9.5" text-anchor="middle" fill="#5c6875">Thread.Sleep(3000)</text>
      <text x="79" y="180" font-size="9" font-weight="bold" text-anchor="middle" fill="#8f2419">never do this</text>
      <rect x="150" y="140" width="600" height="26" rx="3" fill="#f0d9a8" stroke="#a06000"/>
      <text x="450" y="157" font-size="10" text-anchor="middle" fill="#7a4a00">waits the full 3 seconds regardless</text>
      <rect x="750" y="140" width="16" height="26" rx="3" fill="#177a3c"/>
      <text x="200" y="187" font-size="10" fill="#8f2419">passes — but wastes 1.6s HERE, and still fails on the day the app takes 3.1s</text>
      <rect x="14" y="212" width="130" height="72" rx="6" fill="#e8f3ea" stroke="#177a3c" stroke-width="2"/>
      <text x="79" y="232" font-size="10.5" font-weight="bold" text-anchor="middle" fill="#0f5528">EXPLICIT WAIT</text>
      <text x="79" y="249" font-size="9.5" text-anchor="middle" fill="#5c6875">wait until clickable,</text>
      <text x="79" y="264" font-size="9.5" text-anchor="middle" fill="#5c6875">up to 10s</text>
      <text x="79" y="279" font-size="9" font-weight="bold" text-anchor="middle" fill="#0f5528">the right answer</text>
      <rect x="150" y="226" width="14" height="22" rx="2" fill="#9ec6a9"/>
      <rect x="190" y="226" width="14" height="22" rx="2" fill="#9ec6a9"/>
      <rect x="230" y="226" width="14" height="22" rx="2" fill="#9ec6a9"/>
      <rect x="270" y="226" width="14" height="22" rx="2" fill="#9ec6a9"/>
      <rect x="310" y="226" width="14" height="22" rx="2" fill="#9ec6a9"/>
      <rect x="350" y="226" width="14" height="22" rx="2" fill="#9ec6a9"/>
      <rect x="390" y="226" width="14" height="22" rx="2" fill="#9ec6a9"/>
      <rect x="430" y="226" width="14" height="22" rx="2" fill="#9ec6a9"/>
      <rect x="470" y="226" width="14" height="22" rx="2" fill="#9ec6a9"/>
      <rect x="510" y="226" width="14" height="22" rx="2" fill="#9ec6a9"/>
      <rect x="550" y="226" width="14" height="22" rx="2" fill="#9ec6a9"/>
      <rect x="590" y="226" width="14" height="22" rx="2" fill="#9ec6a9"/>
      <rect x="630" y="226" width="14" height="22" rx="2" fill="#9ec6a9"/>
      <rect x="670" y="226" width="14" height="22" rx="2" fill="#9ec6a9"/>
      <rect x="710" y="222" width="18" height="30" rx="3" fill="#177a3c"/>
      <text x="430" y="266" font-size="10" text-anchor="middle" fill="#0f5528">polls every ~0.5s: "is it clickable yet?"  no · no · no · no ...</text>
      <text x="745" y="240" font-size="10.5" font-weight="bold" fill="#0f5528">YES → proceeds instantly</text>
      <rect x="14" y="300" width="910" height="70" rx="8" fill="#fffdf7" stroke="#d99500"/>
      <text x="32" y="322" font-size="11.5" font-weight="bold" fill="#7a4a00">WHY THE THIRD ONE IS BOTH FASTER AND MORE RELIABLE — this is the whole argument</text>
      <text x="32" y="344" font-size="10.5" fill="#33404f">A sleep is a GUESS about how long the app takes. It is simultaneously too long on a good day and too short on a bad one.</text>
      <text x="32" y="362" font-size="10.5" fill="#33404f">An explicit wait states a CONDITION and stops the moment it is true — so the suite gets quicker AND stops flaking. Not a trade-off.</text>
    </svg>
  </div>
  '''

FLAKE = '''<div class="diag">
    <svg viewBox="0 0 940 300" xmlns="http://www.w3.org/2000/svg" ''' + F + '''>
      <defs><marker id="fk" markerWidth="9" markerHeight="9" refX="8" refY="4.5" orient="auto">
        <path d="M0,0 L9,4.5 L0,9 z" fill="#8b97a4"/></marker></defs>
      <text x="14" y="18" font-size="11" font-weight="bold" fill="#5c6875">THE SEVEN CAUSES — use this as a diagnostic order, not a list</text>
      <rect x="374" y="130" width="192" height="46" rx="8" fill="#fbe9e6" stroke="#c0392b" stroke-width="2.5"/>
      <text x="470" y="150" font-size="12" font-weight="bold" text-anchor="middle" fill="#8f2419">"IT'S FLAKY"</text>
      <text x="470" y="167" font-size="9.5" text-anchor="middle" fill="#5c6875">passes and fails, app unchanged</text>
      <rect x="20" y="34" width="188" height="46" rx="6" fill="#e8f3ea" stroke="#177a3c"/>
      <text x="114" y="52" font-size="10.5" font-weight="bold" text-anchor="middle" fill="#0f5528">1. TIMING</text>
      <text x="114" y="68" font-size="9.5" text-anchor="middle" fill="#5c6875">acted before ready — start here</text>
      <rect x="20" y="92" width="188" height="46" rx="6" fill="#e8f3ea" stroke="#177a3c"/>
      <text x="114" y="110" font-size="10.5" font-weight="bold" text-anchor="middle" fill="#0f5528">2. TEST DATA</text>
      <text x="114" y="126" font-size="9.5" text-anchor="middle" fill="#5c6875">consumed, changed, or gone</text>
      <rect x="20" y="150" width="188" height="46" rx="6" fill="#fdf3dd" stroke="#a06000"/>
      <text x="114" y="168" font-size="10.5" font-weight="bold" text-anchor="middle" fill="#7a4a00">3. TEST ORDER</text>
      <text x="114" y="184" font-size="9.5" text-anchor="middle" fill="#5c6875">one test depends on another</text>
      <rect x="20" y="208" width="188" height="46" rx="6" fill="#fdf3dd" stroke="#a06000"/>
      <text x="114" y="226" font-size="10.5" font-weight="bold" text-anchor="middle" fill="#7a4a00">4. SHARED STATE</text>
      <text x="114" y="242" font-size="9.5" text-anchor="middle" fill="#5c6875">parallel tests colliding</text>
      <rect x="732" y="34" width="188" height="46" rx="6" fill="#fdf3dd" stroke="#a06000"/>
      <text x="826" y="52" font-size="10.5" font-weight="bold" text-anchor="middle" fill="#7a4a00">5. ENVIRONMENT</text>
      <text x="826" y="68" font-size="9.5" text-anchor="middle" fill="#5c6875">slow, loaded, being deployed to</text>
      <rect x="732" y="92" width="188" height="46" rx="6" fill="#fbe9e6" stroke="#c0392b"/>
      <text x="826" y="110" font-size="10.5" font-weight="bold" text-anchor="middle" fill="#8f2419">6. LOCATORS</text>
      <text x="826" y="126" font-size="9.5" text-anchor="middle" fill="#5c6875">match sometimes, or match two</text>
      <rect x="732" y="150" width="188" height="46" rx="6" fill="#fbe9e6" stroke="#c0392b" stroke-width="2"/>
      <text x="826" y="168" font-size="10.5" font-weight="bold" text-anchor="middle" fill="#8f2419">7. A REAL DEFECT</text>
      <text x="826" y="184" font-size="9.5" text-anchor="middle" fill="#5c6875">an actual race in the product</text>
      <line x1="208" y1="57"  x2="370" y2="140" stroke="#8b97a4" stroke-width="1.5" marker-end="url(#fk)"/>
      <line x1="208" y1="115" x2="370" y2="147" stroke="#8b97a4" stroke-width="1.5" marker-end="url(#fk)"/>
      <line x1="208" y1="173" x2="370" y2="155" stroke="#8b97a4" stroke-width="1.5" marker-end="url(#fk)"/>
      <line x1="208" y1="231" x2="370" y2="165" stroke="#8b97a4" stroke-width="1.5" marker-end="url(#fk)"/>
      <line x1="732" y1="57"  x2="570" y2="140" stroke="#8b97a4" stroke-width="1.5" marker-end="url(#fk)"/>
      <line x1="732" y1="115" x2="570" y2="147" stroke="#8b97a4" stroke-width="1.5" marker-end="url(#fk)"/>
      <line x1="732" y1="173" x2="570" y2="157" stroke="#8b97a4" stroke-width="1.5" marker-end="url(#fk)"/>
      <rect x="230" y="212" width="480" height="76" rx="8" fill="#fffdf7" stroke="#d99500"/>
      <text x="470" y="234" font-size="11" font-weight="bold" text-anchor="middle" fill="#7a4a00">CAUSE 7 IS THE ONE THAT MATTERS</text>
      <text x="470" y="255" font-size="10" text-anchor="middle" fill="#33404f">Every re-run culture exists to make 1–6 go away. It also hides 7.</text>
      <text x="470" y="273" font-size="10" font-weight="bold" text-anchor="middle" fill="#8f2419">A race condition in the product looks EXACTLY like a flaky test — until a customer finds it.</text>
    </svg>
  </div>
  '''

NUNIT = '''<div class="diag">
    <svg viewBox="0 0 940 320" xmlns="http://www.w3.org/2000/svg" ''' + F + '''>
      <defs><marker id="n1" markerWidth="9" markerHeight="9" refX="8" refY="4.5" orient="auto">
        <path d="M0,0 L9,4.5 L0,9 z" fill="#5c6875"/></marker></defs>
      <text x="14" y="18" font-size="11" font-weight="bold" fill="#5c6875">THE ORDER THINGS HAPPEN IN — and where the browser should be created</text>
      <rect x="30" y="30" width="880" height="238" rx="8" fill="#fafbfd" stroke="#6a3fa0" stroke-dasharray="5 4"/>
      <text x="46" y="50" font-size="10.5" font-weight="bold" fill="#3d2464">[OneTimeSetUp] — ONCE per fixture</text>
      <text x="330" y="50" font-size="10" fill="#5c6875">config, database seed, anything expensive and READ-ONLY</text>
      <rect x="56" y="62" width="828" height="176" rx="7" fill="#fff" stroke="#1a6bd4" stroke-dasharray="4 3"/>
      <text x="72" y="82" font-size="10.5" font-weight="bold" fill="#134b96">[SetUp] — before EVERY test</text>
      <text x="330" y="82" font-size="10" font-weight="bold" fill="#8f2419">create the browser HERE, not above</text>
      <rect x="86" y="96" width="768" height="60" rx="6" fill="#e8f3ea" stroke="#177a3c" stroke-width="2"/>
      <text x="470" y="118" font-size="12" font-weight="bold" text-anchor="middle" fill="#0f5528">[Test]  —  arrange · act · ASSERT</text>
      <text x="470" y="138" font-size="10" text-anchor="middle" fill="#5c6875">runs once per test, or once per data row if it is data-driven</text>
      <text x="72" y="180" font-size="10.5" font-weight="bold" fill="#134b96">[TearDown] — after EVERY test</text>
      <text x="330" y="180" font-size="10" fill="#5c6875">screenshot IF failed, then Quit() the browser — always, even on failure</text>
      <rect x="86" y="192" width="768" height="34" rx="6" fill="#fdf3dd" stroke="#a06000"/>
      <text x="470" y="213" font-size="10" text-anchor="middle" fill="#7a4a00">this is the ONLY place a screenshot of the failure still exists — capture it before you close anything</text>
      <text x="46" y="258" font-size="10.5" font-weight="bold" fill="#3d2464">[OneTimeTearDown] — ONCE at the end</text>
      <text x="330" y="258" font-size="10" fill="#5c6875">shared cleanup, final reporting</text>
      <rect x="30" y="282" width="880" height="32" rx="6" fill="#fbe9e6" stroke="#c0392b"/>
      <text x="470" y="303" font-size="10.5" font-weight="bold" text-anchor="middle" fill="#8f2419">THE PARALLEL TRAP: anything created in OneTimeSetUp is SHARED. Put a browser there and parallel tests fight over it.</text>
    </svg>
  </div>
  '''

GRID = '''<div class="diag">
    <svg viewBox="0 0 940 300" xmlns="http://www.w3.org/2000/svg" ''' + F + '''>
      <defs><marker id="g2" markerWidth="9" markerHeight="9" refX="8" refY="4.5" orient="auto">
        <path d="M0,0 L9,4.5 L0,9 z" fill="#5c6875"/></marker></defs>
      <text x="14" y="18" font-size="11" font-weight="bold" fill="#5c6875">GRID — one address, many browsers, somewhere else</text>
      <rect x="20" y="90" width="150" height="70" rx="7" fill="#e4edfa" stroke="#1a6bd4"/>
      <text x="95" y="115" font-size="11" font-weight="bold" text-anchor="middle" fill="#134b96">YOUR TESTS</text>
      <text x="95" y="133" font-size="9.5" text-anchor="middle" fill="#5c6875">point at ONE url</text>
      <text x="95" y="148" font-size="9.5" text-anchor="middle" fill="#5c6875">and ask for a browser</text>
      <line x1="170" y1="125" x2="228" y2="125" stroke="#5c6875" stroke-width="2" marker-end="url(#g2)"/>
      <rect x="234" y="66" width="180" height="118" rx="7" fill="#fdf3dd" stroke="#a06000" stroke-width="2"/>
      <text x="324" y="88" font-size="11" font-weight="bold" text-anchor="middle" fill="#7a4a00">THE HUB</text>
      <text x="324" y="107" font-size="9.5" text-anchor="middle" fill="#5c6875">router — takes the request</text>
      <text x="324" y="122" font-size="9.5" text-anchor="middle" fill="#5c6875">queue — holds it if busy</text>
      <text x="324" y="137" font-size="9.5" text-anchor="middle" fill="#5c6875">distributor — picks a node</text>
      <text x="324" y="152" font-size="9.5" text-anchor="middle" fill="#5c6875">session map — remembers who</text>
      <text x="324" y="172" font-size="9.5" font-weight="bold" text-anchor="middle" fill="#8f2419">one box, or four services</text>
      <line x1="414" y1="100" x2="470" y2="66" stroke="#5c6875" stroke-width="1.6" marker-end="url(#g2)"/>
      <line x1="414" y1="125" x2="470" y2="125" stroke="#5c6875" stroke-width="1.6" marker-end="url(#g2)"/>
      <line x1="414" y1="150" x2="470" y2="184" stroke="#5c6875" stroke-width="1.6" marker-end="url(#g2)"/>
      <rect x="476" y="42" width="200" height="48" rx="6" fill="#e8f3ea" stroke="#177a3c"/>
      <text x="576" y="62" font-size="10.5" font-weight="bold" text-anchor="middle" fill="#0f5528">NODE — Chrome x5</text>
      <text x="576" y="79" font-size="9.5" text-anchor="middle" fill="#5c6875">a machine that actually runs browsers</text>
      <rect x="476" y="102" width="200" height="48" rx="6" fill="#e8f3ea" stroke="#177a3c"/>
      <text x="576" y="122" font-size="10.5" font-weight="bold" text-anchor="middle" fill="#0f5528">NODE — Firefox x3</text>
      <text x="576" y="139" font-size="9.5" text-anchor="middle" fill="#5c6875">registers what it can offer</text>
      <rect x="476" y="162" width="200" height="48" rx="6" fill="#e8f3ea" stroke="#177a3c"/>
      <text x="576" y="182" font-size="10.5" font-weight="bold" text-anchor="middle" fill="#0f5528">NODE — Edge x2</text>
      <text x="576" y="199" font-size="9.5" text-anchor="middle" fill="#5c6875">the hub matches request to node</text>
      <rect x="700" y="42" width="222" height="168" rx="7" fill="#fffdf7" stroke="#d99500"/>
      <text x="811" y="64" font-size="10.5" font-weight="bold" text-anchor="middle" fill="#7a4a00">THE MODERN ANSWER</text>
      <text x="714" y="86" font-size="10" fill="#33404f">Don't run permanent nodes.</text>
      <text x="714" y="104" font-size="10" fill="#33404f">Start browser containers per</text>
      <text x="714" y="122" font-size="10" fill="#33404f">run and throw them away.</text>
      <text x="714" y="146" font-size="10" font-weight="bold" fill="#8f2419">Why: a long-lived node drifts.</text>
      <text x="714" y="164" font-size="10" fill="#33404f">Cached state, leftover profiles,</text>
      <text x="714" y="182" font-size="10" fill="#33404f">a browser that auto-updated.</text>
      <text x="714" y="202" font-size="10" font-weight="bold" fill="#0f5528">Fresh every time = reproducible.</text>
      <rect x="20" y="230" width="902" height="60" rx="8" fill="#fbe9e6" stroke="#c0392b"/>
      <text x="38" y="252" font-size="11" font-weight="bold" fill="#8f2419">THE THING TO SAY ABOUT SCALE</text>
      <text x="38" y="273" font-size="10.5" fill="#33404f">Grid solves CAPACITY. It does not solve flakiness — and running an unreliable suite in parallel produces failures faster, not fewer.</text>
    </svg>
  </div>
  '''

QUADRANT = '''<div class="diag">
    <svg viewBox="0 0 940 400" xmlns="http://www.w3.org/2000/svg" ''' + F + '''>
      <text x="14" y="18" font-size="11" font-weight="bold" fill="#5c6875">WHAT TO AUTOMATE — the two questions that actually decide it</text>
      <line x1="180" y1="40" x2="180" y2="330" stroke="#8b97a4" stroke-width="2"/>
      <line x1="180" y1="330" x2="820" y2="330" stroke="#8b97a4" stroke-width="2"/>
      <text x="500" y="356" font-size="11" font-weight="bold" text-anchor="middle" fill="#243447">HOW OFTEN DOES IT RUN?  →</text>
      <text x="30" y="185" font-size="11" font-weight="bold" fill="#243447">HOW STABLE</text>
      <text x="30" y="202" font-size="11" font-weight="bold" fill="#243447">IS THE UI?</text>
      <text x="30" y="219" font-size="11" font-weight="bold" fill="#243447">↑</text>
      <rect x="190" y="50" width="308" height="130" rx="7" fill="#fdf3dd" stroke="#a06000"/>
      <text x="344" y="76" font-size="11.5" font-weight="bold" text-anchor="middle" fill="#7a4a00">STABLE, RARELY RUN</text>
      <text x="344" y="100" font-size="10" text-anchor="middle" fill="#33404f">Automate only if it is expensive to do</text>
      <text x="344" y="117" font-size="10" text-anchor="middle" fill="#33404f">by hand, or needed for compliance evidence.</text>
      <text x="344" y="145" font-size="10" font-weight="bold" text-anchor="middle" fill="#8f2419">Annual regulatory scenario:</text>
      <text x="344" y="162" font-size="10" text-anchor="middle" fill="#33404f">the maintenance may exceed the saving.</text>
      <rect x="504" y="50" width="308" height="130" rx="7" fill="#e8f3ea" stroke="#177a3c" stroke-width="2.5"/>
      <text x="658" y="76" font-size="11.5" font-weight="bold" text-anchor="middle" fill="#0f5528">STABLE, RUNS CONSTANTLY</text>
      <text x="658" y="100" font-size="10.5" font-weight="bold" text-anchor="middle" fill="#0f5528">AUTOMATE FIRST. Every time.</text>
      <text x="658" y="124" font-size="10" text-anchor="middle" fill="#33404f">Core regression, smoke, login, checkout.</text>
      <text x="658" y="141" font-size="10" text-anchor="middle" fill="#33404f">Highest return, lowest maintenance,</text>
      <text x="658" y="158" font-size="10" text-anchor="middle" fill="#33404f">and it buys the credibility for everything else.</text>
      <rect x="190" y="192" width="308" height="130" rx="7" fill="#fbe9e6" stroke="#c0392b" stroke-width="2"/>
      <text x="344" y="218" font-size="11.5" font-weight="bold" text-anchor="middle" fill="#8f2419">VOLATILE, RARELY RUN</text>
      <text x="344" y="242" font-size="10.5" font-weight="bold" text-anchor="middle" fill="#8f2419">DO NOT AUTOMATE.</text>
      <text x="344" y="266" font-size="10" text-anchor="middle" fill="#33404f">Exploratory testing is genuinely better here —</text>
      <text x="344" y="283" font-size="10" text-anchor="middle" fill="#33404f">a human finds things a script cannot,</text>
      <text x="344" y="300" font-size="10" text-anchor="middle" fill="#33404f">and there is nothing stable to encode yet.</text>
      <rect x="504" y="192" width="308" height="130" rx="7" fill="#fdf3dd" stroke="#a06000"/>
      <text x="658" y="218" font-size="11.5" font-weight="bold" text-anchor="middle" fill="#7a4a00">VOLATILE, RUNS CONSTANTLY</text>
      <text x="658" y="240" font-size="10" text-anchor="middle" fill="#33404f">The genuinely hard quadrant.</text>
      <text x="658" y="262" font-size="10" font-weight="bold" text-anchor="middle" fill="#8f2419">Automate BELOW the UI — API and data —</text>
      <text x="658" y="279" font-size="10" font-weight="bold" text-anchor="middle" fill="#8f2419">and keep the screen coverage thin.</text>
      <text x="658" y="301" font-size="10" text-anchor="middle" fill="#33404f">Or fix the volatility first: agree test attributes.</text>
      <rect x="180" y="366" width="640" height="30" rx="6" fill="#fffdf7" stroke="#d99500"/>
      <text x="500" y="386" font-size="10.5" font-weight="bold" text-anchor="middle" fill="#7a4a00">"What should we automate?" is really "where does the maintenance cost stay below the saving?"</text>
    </svg>
  </div>
  '''

INSERTS = [
    ('<h4>0.3 — So what does', DOM),
    ('<h4>0.5 — One complete test', CAST),
    ('<b class="lbl">The three consequences', STALE),
    ('<h4>"CSS or XPath?"', LOCATORS),
    ('<h4>The specific conditions worth naming out loud</h4>', WAITS),
    ('<h4>The 7 causes of flaky tests', FLAKE),
    ('<h4>Running many tests at once</h4>', NUNIT),
    ('<h4>The modern approach: containers', GRID),
    ('<h4>When NOT to automate</h4>', QUADRANT),
]

# anchors that sit inside a box: rewind to the enclosing <div class="box...> line
REWIND = {'<b class="lbl">The three consequences'}


def main():
    src = open(P, encoding="utf-8").read()
    if src.count("<svg") > 4:
        print("already inserted — aborting"); return 1
    added = 0
    for anchor, svg in INSERTS:
        i = src.find(anchor)
        if i < 0:
            print("  MISS:", anchor[:52].replace("\n", " ")); continue
        if anchor in REWIND:
            i = src.rfind('<div class="box', 0, i)
        src = src[:i] + svg + src[i:]
        added += 1
    open(P, "w", encoding="utf-8").write(src)
    print("inserted %d of %d diagrams" % (added, len(INSERTS)))
    return 0


if __name__ == "__main__":
    sys.exit(main())
