# Archive

Nothing here is deleted — everything is recoverable. Four groups:

## `2026-09-04-story-thread/` (22 files)
Originals of every file modified when the **Prairie Harvest story thread** was added
(2026-09-04): all 21 Day *Expanded* guides plus `index.html`, with original timestamps intact.

Restore any of these by copying back over the live file in the root folder.

## `superseded-ai-track-plans/` (3 files)
`AI-Track-00-Plan.html`, `-v3`, `-v4`. **Superseded by `AI-Track-00-Plan-v5.html`**, which
stays live in the root and is the version linked from `index.html`.

v5 restructured the plan around "Milestones at a glance" and a day-by-day schedule;
v4 and earlier used a different spine ("Why this order and no other", "The four exams").
Nothing in the root links to v1/v3/v4.

## `legacy-2026-08-13/` (was `Archive-Legacy-2026-08-13/`)
The pre-13-August generation of the curriculum, archived at that time. Kept as-is,
just relocated under `Archive/` so all archived material sits in one place.

## `claude-branch/` (was `Claude/`) — **read this note**
A divergent working branch containing alternate builds of Day 01 and Day 02.

**These are not simply older files.** They contain sections that the live root versions
do **not** have:

| File | Section present here but missing from the live root file |
|---|---|
| `Day01-Selenium-Expanded.html` | `11c. Story bank — turn this into your own material` |
| `Day02-Playwright-Expanded.html` | `11. Hands-on studio — three exercises that produce artefacts`<br>`12. Error dictionary and troubleshooting playbook` |

The live root files have their own content this branch lacks (the newer expanded structure
plus the Prairie Harvest story thread), so neither side is a superset of the other.

**RESOLVED 2026-09-04.** The two sections the live files genuinely lacked have been ported back:

- `Day01-Selenium-Expanded.html` → **Story bank** restored (section `#storybank`)
- `Day02-Playwright-Expanded.html` → **Error dictionary and troubleshooting playbook** restored (section `#errors`)

The branch's "Hands-on studio" was *not* ported: the live Day 02 already has its own
Hands-on 1–3 and a Story bank, so that content was duplicative rather than missing.
Nothing further is needed from this branch — it is kept only as history.

---

## Still live in the root (deliberately not archived)

- `AI-Track-00-Plan-v5.html` — current plan version
- `AI-Track-00-Roadmap.html` — higher-level track view, linked from the index
- `AI-Track-F1-What-AI-Means.html` — single-session foundational model, linked from the index
- `AI-Track-Module0-Master.html` — full AI foundations course
- `Claude-Cert-Associate-Developer-Master.html` — certification guide
- `_build/`, `_tools/`, `Audio/`, `AI Images/` — scripts and assets, not curriculum content
