#!/usr/bin/env python3
"""
Full-width diagrams, notes stacked underneath, no horizontal scrolling.

Two root causes fixed:
  1. `.map` was a 2-column grid, squeezing the diagram into ~2/3 width
  2. `svg { min-width: 720px }` forced the SVG wider than its container,
     which is what produced the scrollbar and the clipped/overlapping look

Usage:  python3 fix_layout.py [file.html ...]      (default: all *.html)
"""
import re, sys, os, glob

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MARK = "/* == layout-fix v1 == */"

CSS = MARK + """
/* diagrams take the full column; side notes move underneath */
.map{display:block !important}
.map > .diagram{margin:18px 0 0 !important}
.map > .notes{margin:12px 0 20px !important}

/* never force an SVG wider than its container — this is what caused scrolling */
.diagram{overflow:visible !important}
.diagram svg, .map svg, svg{min-width:0 !important; max-width:100% !important;
                            width:100% !important; height:auto !important; display:block}

/* notes read badly as one very long line when full width */
.notes dl{columns:2; column-gap:28px}
.notes dl dt{break-after:avoid-column; -webkit-column-break-after:avoid}
.notes dl dd{break-inside:avoid-column; -webkit-column-break-inside:avoid; margin-bottom:10px}
.notes > p, .notes > .box{break-inside:avoid}

@media(max-width:900px){
  .two,.three,.outcomes{grid-template-columns:1fr !important}
  .notes dl{columns:1}
}
@media print{
  .map > .diagram, .map > .notes{break-inside:avoid}
}
"""


def patch(path):
    s = open(path, encoding="utf-8").read()
    if MARK in s:
        return "already"
    if "<style>" not in s:
        return None
    # append at the end of the LAST style block so it wins on cascade order
    i = s.rfind("</style>")
    s = s[:i] + "\n" + CSS + "\n" + s[i:]
    open(path, "w", encoding="utf-8").write(s)
    return "patched"


def main():
    files = sys.argv[1:] or sorted(glob.glob(os.path.join(ROOT, "*.html")))
    for f in files:
        r = patch(f)
        if r:
            print("  %-52s %s" % (os.path.basename(f), r))
    print("done")


if __name__ == "__main__":
    main()
