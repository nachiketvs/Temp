#!/usr/bin/env python3
import json, glob, os, subprocess, sys
HERE=os.path.dirname(os.path.abspath(__file__))
d=json.load(open(os.path.join(HERE,'meta.json'),encoding='utf-8'))
secs=[]
for p in sorted(glob.glob(os.path.join(HERE,'s*.json'))):
    secs += json.load(open(p,encoding='utf-8'))
qs=json.load(open(os.path.join(HERE,'q.json'),encoding='utf-8'))
d['sections']=secs; d['questions']=qs
json.dump(d,open(os.path.join(HERE,'_full.json'),'w',encoding='utf-8'),indent=1)
qsec={s['qsec'] for s in secs if s.get('qsec')}; used={q[0] for q in qs}
print('sections',len(secs),'questions',len(qs))
print('orphan q-tags:',used-qsec or 'none','| empty sections:',qsec-used or 'none')
