#!/usr/bin/env python3
"""
Darkens LIGHT TEXT COLOURS only, across the guides.

Rules:
  * inside <text> / <tspan> SVG tags, a light `fill` is a text colour -> darken
  * in CSS, `color:` declarations that are light -> darken
  * shape fills, strokes, backgrounds and borders are NEVER touched

Usage:  python3 darken_text.py [file.html ...]      (default: all *.html)
"""
import re, sys, os, glob

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# explicit mapping for the palette actually in use, so results are predictable
MAP = {
    "#556476": "#111820",   # diagram section headers  <-- the one that was unreadable
    "#8a94a6": "#333d4b",   # small annotations
    "#9aa5b1": "#333d4b",
    "#8b97a4": "#2f3a47",
    "#5c6875": "#232d3a",
    "#7a8593": "#2b3542",
    "#a8b2bd": "#333d4b",
    "#98a3b0": "#333d4b",
    "#6b7684": "#232d3a",
    "#4a5563": "#1b2430",
    "#39434f": "#161d26",
    "#344456": "#141b24",
    "#33404f": "#161d26",
    "#2f3b49": "#161d26",
    "#25303d": "#141b24",
    "#243447": "#131a24",
}

HEX = re.compile(r"#([0-9a-fA-F]{6})\b")


def lum(h):
    r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
    return 0.2126 * r + 0.7152 * g + 0.0722 * b


def darken(hexcode):
    """Map a light colour to a dark one, preserving a hint of its hue."""
    key = hexcode.lower()
    if key in MAP:
        return MAP[key]
    h = key[1:]
    if lum(h) <= 110:              # already dark enough
        return hexcode
    r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
    f = 0.32                        # pull hard toward black, keep a trace of hue
    return "#%02x%02x%02x" % (int(r * f), int(g * f), int(b * f))


def fix_svg_text(html):
    """Only touch fill= on <text> and <tspan> elements."""
    n = [0]

    def tag(m):
        whole = m.group(0)

        def f(fm):
            old = fm.group(1)
            new = darken(old)
            if new.lower() != old.lower():
                n[0] += 1
            return 'fill="%s"' % new

        out = re.sub(r'fill="(#[0-9a-fA-F]{6})"', f, whole)

        def f2(fm):
            old = fm.group(1)
            new = darken(old)
            if new.lower() != old.lower():
                n[0] += 1
            return "fill='%s'" % new

        return re.sub(r"fill='(#[0-9a-fA-F]{6})'", f2, out)

    html = re.sub(r"<(?:text|tspan)\b[^>]*>", tag, html)
    return html, n[0]


def fix_css_color(html):
    """Only touch `color:` (never background-color / border-color)."""
    n = [0]

    def f(m):
        old = m.group(2)
        new = darken(old)
        if new.lower() != old.lower():
            n[0] += 1
        return m.group(1) + new

    html = re.sub(r"(?<!-)\b(color\s*:\s*)(#[0-9a-fA-F]{6})", f, html)
    # the shared muted variable, used for captions and labels
    html = re.sub(r"(--muted\s*:\s*)(#[0-9a-fA-F]{6})",
                  lambda m: m.group(1) + darken(m.group(2)), html)
    return html, n[0]


def process(path):
    s = open(path, encoding="utf-8").read()
    s, a = fix_svg_text(s)
    s, b = fix_css_color(s)
    if a or b:
        open(path, "w", encoding="utf-8").write(s)
    return a, b


def main():
    files = sys.argv[1:] or sorted(glob.glob(os.path.join(ROOT, "*.html")))
    for f in files:
        a, b = process(f)
        if a or b:
            print("  %-52s svg-text:%-4d css-color:%d" % (os.path.basename(f), a, b))
    print("done")


if __name__ == "__main__":
    main()
